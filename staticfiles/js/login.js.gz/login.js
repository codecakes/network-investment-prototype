console.log("dvjbvjkbvjkdvjkd")
$(function(){
    console.log("console.log .....   ....   ....")
    $("#E-mail").change(function(evt){
        console.log(evt,"dnjnjfncalll")
    })

    $("#register").click(function(evt){
        //evt.stopPropagation();
        //evt.preventdefault()
        console.log("reg click")
    })
})